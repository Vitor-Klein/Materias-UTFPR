namespace Exercicio_06.Models;

public class Obra(string titulo, string artista) {
    public string Titulo { get; set; } = titulo;
    public string Artista { get; set; } = artista;
}
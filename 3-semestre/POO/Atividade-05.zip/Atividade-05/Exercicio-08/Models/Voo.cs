namespace Exercicio_08.Models;

public class Voo(int numero, string destino) {
    public int Numero { get; set; } = numero;
    public string Destino { get; set; } = destino;
}
namespace Exercicio_09.Models;

public class Peca(string titulo, string diretor) {
    public string Titulo { get; set; } = titulo;
    public string Diretor { get; set; } = diretor;
}
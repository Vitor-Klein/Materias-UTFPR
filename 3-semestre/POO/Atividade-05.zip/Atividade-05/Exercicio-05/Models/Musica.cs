namespace Exercicio_05.Models;

public class Musica(string titulo, string artista) {
    public string Titulo { get; set; } = titulo;
    public string Artista { get; set; } = artista;
}